package com.assignment.spring.Assignment_Spring.domain;

public class UserSearchForm {
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    String firstname;
    String lastname;
}
