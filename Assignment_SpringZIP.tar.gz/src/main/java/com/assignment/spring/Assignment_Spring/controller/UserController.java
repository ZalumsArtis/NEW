package com.assignment.spring.Assignment_Spring.controller;


import com.assignment.spring.Assignment_Spring.domain.LoginForm;
import com.assignment.spring.Assignment_Spring.domain.User;
import com.assignment.spring.Assignment_Spring.domain.UserSearchForm;
import com.assignment.spring.Assignment_Spring.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(value = "/user")
public class UserController {
    @Autowired
    UserService userService;


    @RequestMapping(value = "/register", method = RequestMethod.GET )
    public String registerView(Model model)
    {
        User user = new User();
        model.addAttribute("user", user );
        return "register";
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST )
    //@ResponseBody
    public String register(Model model, @Valid @ModelAttribute("user") User user, BindingResult bindingResult)
    {
        if (bindingResult.hasErrors())
        {
            model.addAttribute("user", user);
            model.addAttribute("message" ,"Your provided infromation seems not to be correct, please try again");
            return "register";
        }
        userService.save(user);
        return "redirect:/";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET )
    public String loginView(Model model)
    {
        LoginForm user = new LoginForm();
        model.addAttribute("user", user );
        return "login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST )
    //@ResponseBody
    public String login(Model model, @Valid @ModelAttribute("user") LoginForm user, BindingResult bindingResult
    ,HttpSession session)
    {
        if (bindingResult.hasErrors())
        {
            model.addAttribute("user", user);
            model.addAttribute("message" ,"Your provided infromation seems not to be correct, please try again");
            return "login";
        }

        if(userService.validateLogin(user)==false)
        {
            model.addAttribute("user", user);
            model.addAttribute("message" ,"Your information is incorrect");
            return "login";


        }

        session.setAttribute("login", true);
       // userService.save(user);
        return "redirect:/";
    }

    @RequestMapping(value = "/search", method = RequestMethod.GET )
    public String searchView(Model model)
    {
        UserSearchForm searchForm = new UserSearchForm();
        model.addAttribute("searchCriteria", searchForm );
        return "search";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET )
    public String logout(Model model, HttpSession session)
    {

        session.removeAttribute("login");
        return "redirect:/user/login";
    }

    @RequestMapping(value = "/search", method = RequestMethod.POST )
    public String searchView(Model model, @ModelAttribute("searchCriteria")UserSearchForm searchForm)
    {
        List<User> users = userService.searchUser(searchForm);
        model.addAttribute("searchCriteria", searchForm );
        model.addAttribute("users", users);
        return "search";
    }
    @RequestMapping(value = "/update/{user}", method = RequestMethod.GET)

    public String updateView(Model model, @PathVariable User user)
    {

        model.addAttribute("user", user);
        return "update";
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)

    public String update(Model model, @ModelAttribute("user") User user)
    {

        model.addAttribute("user", user);
        userService.save(user);
        return "redirect:/";
    }

    @RequestMapping(value = "/delete/{user}", method = RequestMethod.GET)
    //@ResponseBody
    public String delete(@PathVariable User user)
    {
            String name = user.getFirstname()+" "+user.getLastname();

            userService.delete(user);

            return "redirect:/";
    }

}
